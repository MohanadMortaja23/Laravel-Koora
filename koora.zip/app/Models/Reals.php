<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reals extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function getVideoPathAttribute()
    {
        return asset('storage/' . $this->video);
    }

    public function Reactions()
    {
        return $this->hasMany(RealReaction::class , 'real_id' , 'id');
    }
    
}
