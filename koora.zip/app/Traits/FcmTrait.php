<?php 

namespace App\Traits ;

use App\Models\Sector;
use Illuminate\Http\Request;
trait FcmTrait {


    public function sendFcmNotifications($token, $event)
    {

        // FCM Configration
        $SERVER_API_KEY = 'AAAAhz9Dy2Q:APA91bE8_vQ5XO1yND3RVMdKXPqwyIhZX4nq9BXAbGz8ojgbKU5r0IbJArxN13m_wC2yJlRvru37eJrbbGVNqzdJQMND5K-KH68mTvo2OkkuwIF3exks0DX2mIKy2UUK6ldvyS7Vw4OC';
        $token_1 = $token;
        $data = [
            "registration_ids" => [
                $token_1
            ],


            "notification" => [

                "title" => $event->details,

                "body" => $event->details ,

                "sound" => "default" // required for sound on ios

            ],

        ];

        $dataString = json_encode($data);

        $headers = [

            'Authorization: key=' . $SERVER_API_KEY,

            'Content-Type: application/json',

        ];

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');

        curl_setopt($ch, CURLOPT_POST, true);

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);

        $response = curl_exec($ch);

        
    }

    
   


  

}