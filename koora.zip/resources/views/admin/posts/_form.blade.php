@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $message)
                <li>{{ $message }}</li>
            @endforeach
        </ul>
    </div>
@endif



<div class="row">
    <div class="form-group col-md-4">
        <label for="exampleFormControlInput1"><strong>صورة المنشور</strong></label>
        <input name="image" rows="2" type="file" class="form-control" rows="3" />
    </div>

    
    <div class="form-group col-md-4">
        <div class="form-group ">
            <label for="exampleFormControlInput1"><strong>نوع المنشور</strong></label>
            <select class="form-control" id="exampleSelect1">
              <option>خبر</option>
              <option>تصويت</option>
            </select>
          </div>
    </div>


    

</div>


<div class="row">
    <div class="form-group col-md-4">
        <label for="exampleFormControlInput1"><strong>محتوى المنشور</strong></label>
        <textarea name="details" rows="2" class="form-control" id="exampleFormControlTextarea1" rows="3">{{ $post->details }}</textarea>
    </div>
</div>

<hr>





<button type="submit" class="btn btn-primary">{{ $button }}</button>
