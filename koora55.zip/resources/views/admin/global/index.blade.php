@extends('layouts.admin')

@section('content')
    <div class="app-title">
        <div>
            <h1><i class="fa fa-laptop"></i>جدول الزبائن</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb side">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">لوحة التحكم</li>
            <li class="breadcrumb-item active"><a href="#">الفرق العالمية</a></li>
        </ul>
    </div>
    <div class="col-md-12">


        <div class="tile">
            @if (Session::has('success'))
                <div class="alert alert-success" role="alert">
                    {{ Session::get('success') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            @endif
            <div class="tile-body">
                <div class="col-md-12 p-2 m-2 row ">
                    <div class="col-md-6 justify-content-end align-items-center">
                        <h5 class="h5"><i class="fa fa-table"></i><strong>جدول الفرق العالمية</strong></h5>
                    </div>
                    <div class="row col-md-6 justify-content-end">
                        <a style="height: 30px; width:130px;" href="{{ route('glob-teams.create') }}"
                            class="btn btn-primary d-flex justify-content-center align-items-center ml-1"><i
                                class="fa fa-plus "></i><small>اضافة فريق </small></a>
                    </div>
                </div>
                {{-- <input style="width: 100%; padding:5px ; margin-bottom:5px;" type="text" name="search"
                    placeholder="Search..."> --}}

                <div class="table-responsive">
                    <table class="table table-hover table-bordered w-100" id="sampleTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الفريق</th>
                                <th>الصورة</th>
                                <th>الحالة</th>
                                <th>التعديلات</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($global as $glo)
                                <tr>
                                    <th>{{ $glo->id }}</th>
                                    <th>{{ $glo->name }}</th>
                                    <th>
                                        <div class="img-thumbnail"
                                            style="background-image: url({{ asset('storage/' . $glo->image) }}) ; height: 75px; width:75px; background-size:cover">

                                        </div>
                                    </th>
                                    <th>
                                        @if ($glo->status)
                                            <strong>
                                                <span class="text-success text-end">مفعل</span>
                                            </strong>
                                        @else
                                            <strong>
                                                <span class="text-danger text-end">مغلق</span>
                                            </strong>
                                        @endif
                                    </th>
                                    <th>
                                        <div style="display: row;" class="row">
                                            <a href="{{ route('glob-teams.edit', $glo->id) }}" class="btn btn-info"><i
                                                    class="fa fa-lg fa-edit"></i></a>
                                            <form action="{{ route('glob-teams.destroy', $glo->id) }}" method="POST">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-danger"><i
                                                        class="fa fa-lg fa-trash"></i></button>
                                            </form>
                                            <div class="toggle lg">
                                                <label>
                                                    <input name="status" type="checkbox" checked
                                                        value="{{ $glo->status == 1 ? '1' : '0' }}"><span
                                                        class="button-indecator"></span>
                                                </label>
                                            </div>
                                        </div>

                                    </th>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

{{-- @section('scripts')
    <script type="text/javascript" src="{{ asset('js/plugins/jquery.dataTables.min.js') }}"></script>
    <script type="text/javascript" src="{{ asset('js/plugins/dataTables.bootstrap.min.js') }}"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    <script type="text/javascript">
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#sampleTable').dataTable({
                processing: true,
                serverSide: true,
                ajax: "{{ route('customers.index') }}",
                columns: [

                    {
                        data: 'id',
                        name: 'id',

                    },
                    {
                        data: 'name',
                        name: 'name'
                    },

                    {
                        data: 'image',
                        name: 'image'
                    },

                    {
                        data: 'department_id',
                        name: 'department_id'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'email',
                        name: 'email'
                    },
                        {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    },
                ]
            });

        });
    </script>
@endsection --}}
