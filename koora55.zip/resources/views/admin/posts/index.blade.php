@extends('layouts.admin')


@section('content')
    <div class="app-title">
        <div>
            <h1><i class="fa fa-laptop"></i> المنشورات</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb side">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">لوحة التحكم</li>
            <li class="breadcrumb-item active"><a href="#">المنشورات</a></li>
        </ul>

        <div>
            <a href="{{route('posts.create')}}" class="btn btn-primary"> اضافة منشور جديد</a>
        </div>
    </div>
    <div class="col-md-12">


        <div class="row">

            @foreach ($posts as $post)
                <div class="col-md-6">
                    <div class="tile">

                        <div class="tile-body container">
                            <div class="row">

                                <h3 class="title">{{ $post->details }}</h3>
                                {{-- @foreach ($post->Medicine as $med)
                                    <div class="col-md-6">
                                        <span class="badge badge-success">{{ $med->name }}</span>
                                    </div>
                                @endforeach --}}
                            </div>

                        </div>

                        <div class="tile-title-w-btn">
                                <img class="" style="height:150px ; width:100%; object-fit: cover" src="{{asset('storage/' . $post->image)}}">
                        </div>
                       
                       





                    </div>
                </div>
            @endforeach


        </div>
    </div>
@endsection
