<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Traits\ApiTrait;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\MessageBag;
use Laravel\Sanctum\PersonalAccessToken;

class AuthController extends Controller
{
   use GeneralTrait  , ApiTrait;
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Login(Request $request)
    {
        $request->validate([
            'email' => ['required'],
            'password' => ['required'],
            'device_name' => ['required'],
        ]);
                                
        $user = User::where('email', $request->email)->first();
        if (!$user || !Hash::check($request->password, $user->password)) {
            $errors = new MessageBag(['password' => ['Email and/or password invalid.']]);
            return Response()->json([
                'message' => 'Invalid username and password combination'
            ], 401);
        }

        $token = $user->createToken($request->device_name);
        $accessToken = PersonalAccessToken::findToken($token->plainTextToken);
        return Response()->Json([
            'status' => true,
            'code' => 200,
            'message' => 'login successfully',
            'user' => new UserResource($user->setAttribute('token', $token->plainTextToken)) ,
        ], 200);
    }

    public function Register(Request $request)
    {
        $request->validate([
           
            'email'=> 'required|email|unique:users,email' ,
            'password' => 'required|min:4|max:16|confirmed',
        ]);
        $request->merge([
            'password' => Hash::make($request->password),

        ]);


        $user = User::create($request->except('password_confirmation'));
        return $this->SuccessApi($user , 'User Created Successfully');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function Information(Request $request)
    {
        $request->validate([
            'first_name'=> 'required|max:50' ,
            'last_name'=> 'required|max:50' ,
            // 'image' => 'required|file|mimes:png,jpg|size:2048',
            
        ]);


        $request->merge([
            'name'=> $request->first_name . ' ' . $request->last_name ,
        ]);
        $user = User::where('id', Auth::guard('sanctum')->id())->first();
        $input = $request->all();
        if($request->image){
            $input['image'] =  $this->imageStore($request , $input , 'image' , 'users/avatars'); 
        }
        $user->name = $request->first_name . ' ' . $request->last_name ;
        if($request->image){
        $user->image = $input['image'] ;
        }
        $user->save();
        
        return $this->SuccessApi($user);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = Auth::guard('sanctum')->user();

        //Rovoke (delete) all users tokens
        //$user->tokens()->delete();

        //Revoke current access Token
        $user->currentAccessToken()->delete();
    }


    public function ResetPassword(Request $request)
    {
        $request->validate([
            'email'=>'nullable|exists:users,email'
        ]);
        return $this->SuccessApi(null , 'لقد قمنا بارسال رسالة الى ايميلك تحتوي كود تغيير كلمة المرور');
    }


    public function verify($user_id) {
       
        $user = User::findOrFail($user_id);
        if (!$user->hasVerifiedEmail()) {
            $user->markEmailAsVerified();
        }

        
        return redirect()->to('/');
    }



}
