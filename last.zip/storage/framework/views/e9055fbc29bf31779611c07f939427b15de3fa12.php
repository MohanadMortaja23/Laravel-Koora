<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-laptop"></i>جدول الفرق المحلية</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb side">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">لوحة التحكم</li>
            <li class="breadcrumb-item active"><a href="#">الفرق المحلية</a></li>
        </ul>
    </div>
    <div class="col-md-12">


        <div class="tile">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(Session::get('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="tile-body">
                <div class="col-md-12 p-2 m-2 row ">
                    <div class="col-md-6 justify-content-end align-items-center">
                        <h5 class="h5"><i class="fa fa-table"></i><strong>جدول الفرق المحلية</strong></h5>
                    </div>
                    <div class="row col-md-6 justify-content-end">
                        <a style="height: 30px; width:130px;" href="<?php echo e(route('locl-teams.create')); ?>"
                            class="btn btn-primary d-flex justify-content-center align-items-center ml-1"><i
                                class="fa fa-plus "></i><small>اضافة فرق محلية </small></a>
                    </div>


                </div>
                

                <div class="table-responsive">

                    <table class="table table-hover table-bordered w-100" id="sampleTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>اسم الفريق</th>
                                <th>الصورة</th>
                                <th>الحالة</th>
                                <th>التعديلات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $local; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loc->id); ?></th>
                                        <th><?php echo e($loc->name); ?></th>
                                        <th>
                                            <div class="img-thumbnail"
                                                style="background-image: url(<?php echo e(asset('storage/' . $loc->image)); ?>) ; height: 75px; width:75px; background-size:cover">
                                            </div>
                                        </th>
                                        <th>
                                            <?php if($loc->status): ?>
                                                <strong>
                                                    <span class="text-success text-end m-2">مفعل</span>
                                                </strong>
                                            <?php else: ?>
                                                <strong>
                                                    <span class="text-danger text-end">قيد الانتظار</span>
                                                </strong>
                                            <?php endif; ?>
                                        </th>
                                        <th style="width: 200px">
                                            <div style="display: row" class="row actions">
                                                <a href="<?php echo e(route('locl-teams.edit', $loc->id)); ?>" class="btn btn-info m-2"><i class="fa fa-lg fa-edit"></i></a>
                                                <a href="javascript::void(0)"  class="btn btn-danger delete m-2"><i class="fa fa-lg fa-trash"></i></a>

                                               
                                                <form action="<?php echo e(route('locl-teams.destroy', $loc->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                </form>
                                                
                                            </div>
                                        </th>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                        <?php echo e($local->links()); ?>

                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
<script>
    $('.delete').on('click', function(e) {
       
        e.preventDefault();
        let element = $(this).parent('.actions').find('form');
        Swal.fire({
                title: 'هل انت متأكد من الحذف ؟',
                text: "سيتم الحذف بشكل نهائي   ",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'نعم ، قم بالحذف',
                cancelButtonText: 'الغاء',

            })
            .then((result) => {
                if (result.isConfirmed) {
                    Swal.fire(

                        'تم الحذف بنجاح!',
                        'تهانينا',
                        'success'
                    )

                    $(element).submit();
                }
            })

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\koora\resources\views/admin/local/index.blade.php ENDPATH**/ ?>