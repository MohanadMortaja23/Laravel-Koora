<?php if($glo->status): ?>
<strong>
<span class="text-success text-end">مفعل</span>
</strong>
<?php else: ?>
<strong>
    <span class="text-danger text-end">مغلق</span>
</strong>
<?php endif; ?><?php /**PATH C:\wamp64\www\koora\resources\views/admin/global/status.blade.php ENDPATH**/ ?>