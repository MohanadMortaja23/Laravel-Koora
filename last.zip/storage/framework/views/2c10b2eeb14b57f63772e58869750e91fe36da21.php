

<div style="display: row;" class="row" >
    <tr>
    
        <a href="<?php echo e(route('global-teams.edit', $glo->id)); ?>" class="btn btn-info"><i class="fa fa-lg fa-edit"></i></a>
        <form action="<?php echo e(route('global-teams.destroy', $glo->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
        <button type="submit" class="btn btn-danger"><i class="fa fa-lg fa-trash"></i></button>
        </form>
        <tr>
            <div class="toggle lg">
                <label>
                    <input name="status" type="checkbox" checked value="<?php echo e(( $glo->status == 1 ) ? '1' : '0'); ?>"><span class="button-indecator"></span>
                </label>
            </div>
        </tr>
    </tr>
    </div>
    <?php /**PATH C:\wamp64\www\koora\resources\views/admin/global/action_icon.blade.php ENDPATH**/ ?>