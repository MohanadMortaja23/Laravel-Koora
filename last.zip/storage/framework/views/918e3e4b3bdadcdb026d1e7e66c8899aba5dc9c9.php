<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
            <h1><i class="fa fa-laptop"></i> المنشورات</h1>

        </div>
        <ul class="app-breadcrumb breadcrumb side">
            <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
            <li class="breadcrumb-item">لوحة التحكم</li>
            <li class="breadcrumb-item active"><a href="#">المنشورات</a></li>
        </ul>

        <div>
            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary"> اضافة منشور جديد</a>
        </div>
    </div>
    <div class="col-md-12">


        <div class="row">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="tile">

                        <div class="tile-body container">
                            <div class="row">

                                <h5 class="title"><?php echo e($post->details); ?></h5>


                            </div>

                        </div>
                        <?php if($post->image): ?>
                            <div class="tile-title-w-btn">
                                <img class="" style="height:150px ; width:100%; object-fit: cover"
                                    src="<?php echo e(asset('storage/' . $post->image)); ?>">
                            </div>
                        <?php else: ?>
                            <?php
                                $vote = $post->vote()->count();
                                if ($vote > 0) {
                                    $percantage = ($vote / $post->Vote->count()) * 100;
                                } else {
                                    $percantage = 0;
                                }
                            ?>
                            <div class="tile-title-w-btn">
                                <?php $__currentLoopData = $post->Options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex flex-column align-items-center img-thumbnail img-circle"
                                        style="width: 50%">
                                        <img class="img-thumbnail img-circle"
                                            style="height:150px ; width:100%; object-fit: cover"
                                            src="<?php echo e(asset('storage/' . $option->image)); ?>">

                                        <div>
                                            <p><?php echo e($percantage); ?>%</p>
                                            <p> <?php echo e($vote); ?> صوت</p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        <?php endif; ?>

                        <hr>
                        


                        <div class="d-flex align-items-center justify-content-between  actions">
                            <div class="d-flex align-items-center justify-content-between">
                                <p class="m-2">عدد الاعجابات
                                   : 10 
                                </p>
                                <p class="m-2"> 
                                    عدد التعليقات
                                    : 10 
                                </p>
                            </div>
                            <div class="toggle lg">
                                <label>
                                    <input name="status" type="checkbox" checked
                                        value="<?php echo e($post->status == 1 ? '1' : '0'); ?>"><span class="button-indecator"></span>
                                </label>
                            </div>
                            <div class="actions">
                           
                            <a href="javascript:void(0)" class="btn btn-danger delete"><i class="fa fa-lg fa-trash"></i></a>
                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-info"><i
                                    class="fa fa-lg fa-edit"></i></a>

                            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>

                            </form>
                            </div>
                        </div>



                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <script>
        $('.delete').on('click', function(e) {
           
            e.preventDefault();
            let element = $(this).parent('.actions').find('form');
            Swal.fire({
                    title: 'هل انت متأكد من الحذف ؟',
                    text: "سيتم الحذف بشكل نهائي   ",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'نعم ، قم بالحذف',
                    cancelButtonText: 'الغاء',

                })
                .then((result) => {
                    if (result.isConfirmed) {
                        Swal.fire(

                            'تم الحذف بنجاح!',
                            'تهانينا',
                            'success'
                        )

                        $(element).submit();
                    }
                })

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\koora\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>