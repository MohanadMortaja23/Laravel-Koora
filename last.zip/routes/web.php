<?php

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\GlobalController;
use App\Http\Controllers\Admin\LocalController;
use App\Http\Controllers\Admin\NationalController;
use App\Http\Controllers\Admin\PostController;
use App\Http\Controllers\Admin\RealController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\PendingTeamController;
use App\Http\Controllers\TestController;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

// use App\Traits\FcmTrait;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('email/verify/{id}', [AuthController::class, 'verify'])->name('verification.verify');


Route::get('send-mail', function () {
   
    $details = [
        'title' => 'Mail from ItSolutionStuff.com',
        'body' => 'This is for testing email using smtp'
    ];
   
    // Mail::to('your_receiver_email@gmail.com')->send(new \App\Mail\MyTestMail($details));
   
    // dd("Email is Sent.");
});


Route::get('/test' , [TestController::class , 'sendFcm']);

Route::prefix('admin')->group(function(){
    
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard.index');
    Route::resource('glob-teams', GlobalController::class);
    Route::resource('locl-teams', LocalController::class);
    Route::resource('natio-teams', NationalController::class);
    Route::resource('suggests-team', PendingTeamController::class);
    Route::post('suggests/status', [PendingTeamController::class, 'status'])->name('suggests.status');
    Route::post('suggests/refuse', [PendingTeamController::class, 'refuse'])->name('suggests.refuse');

    Route::resource('users', UsersController::class);
    Route::post('user/status', [UsersController::class, 'status'])->name('user.status');

    Route::resource('reals', RealController::class);
    Route::resource('posts', PostController::class);

});
