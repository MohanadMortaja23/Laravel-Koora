<!DOCTYPE html>
<html>
<head>
    <title>ItsolutionStuff.com</title>
</head>
<body>
    <h1>{{ $details['title'] }}</h1>
    <p>{{ $details['body'] }}</p>
   
   <a href="{{route('verification.verify' , $id)}}">تأكيد الحساب</a>
</body>
</html>