<div class="img-thumbnail"
    style="background-image: url({{ asset('storage/' . $glo->image) }}) ; height: 75px; width:75px; background-size:cover">

</div>
