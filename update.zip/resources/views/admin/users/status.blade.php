@if ($us->status)
<strong>
<span class="text-success text-end">مفعل</span>
</strong>
@else
<strong>
    <span class="text-danger text-end">مغلق</span>
</strong>
@endif