<div class="img-thumbnail"
    style="background-image: url(<?php echo e(asset('storage/' . $glo->image)); ?>) ; height: 75px; width:75px; background-size:cover">

</div>
<?php /**PATH C:\wamp64\www\koora\resources\views/admin/global/_image.blade.php ENDPATH**/ ?>