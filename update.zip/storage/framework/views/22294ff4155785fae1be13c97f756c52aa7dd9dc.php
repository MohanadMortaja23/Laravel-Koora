<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<?php

$columns = Illuminate\Support\Facades\Schema::getColumnListing('global_teams');
$discard = ['id','created_at', 'updated_at', 'slug' ,'status'] ;
$textarea = ['description'];
$images = ['image'];
$date = ['dob'];
$status = ['status'];
$number = ['value', 'count'];
$filter_data = [];
$selectfields = [];

foreach ($columns as $key => $disc) {
    if (str_contains($disc, '_id')) {
        $word = strstr($disc, '_id', true);
        $plural = Str::plural((string) $word, 2);
        array_push($filter_data, $disc);
        array_push($selectfields, $plural);
    }
}

?>

<div class="row">

    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!in_array($col, $filter_data) && !in_array($col, $discard)): ?>
            <?php if(in_array($col, $textarea)): ?>
                <div class="form-group col-md-4">
                    <label for="exampleFormControlInput1"><strong><?php echo e(__('titles.' . $col)); ?></strong></label>
                    <textarea value="<?php echo e($global->$col); ?>" name="<?php echo e($col); ?>" rows="2" class="form-control" id="exampleFormControlTextarea1" rows="3" ><?php echo e($global->$col); ?></textarea>
                </div>
            <?php elseif(in_array($col, $images)): ?>
                <div class="form-group col-md-4">
                    <label for="exampleFormControlInput1"><strong><?php echo e(__('titles.' . $col)); ?></strong></label>
                    <input type="file" name="<?php echo e($col); ?>" class="form-control">
                </div>
            <?php elseif(in_array($col, $date)): ?>
                <div class="form-group col-md-4">
                    <label for="exampleFormControlInput1"><strong><?php echo e(__('titles.' . $col)); ?></strong></label>
                    <input value="<?php echo e($global->$col); ?>" type="date" name="<?php echo e($col); ?>" class="form-control">
                </div>
            <?php elseif(in_array($col, $status)): ?>
                <div class="form-group col-md-4">
                    <label for="exampleFormControlInput1"><strong><?php echo e(__('titles.' . $col)); ?></strong></label>

                    <div class="toggle lg">
                        <label>
                            <input name="status" type="checkbox" checked value="1"><span
                                class="button-indecator"></span>
                        </label>
                    </div>
                </div>
            <?php elseif(in_array($col, $number)): ?>
                <div class="form-group col-md-4">
                    <label for="exampleFormControlInput1"><strong><?php echo e(__('titles.' . $col)); ?></strong></label>
                    <input type="number" name="<?php echo e($col); ?>" class="form-control" id="exampleFormControlInput1"
                        placeholder=" هنا" value="<?php echo e($global->$col); ?>">
                </div>
            <?php else: ?>
                <div class="form-group col-md-4">
                    <label for="exampleFormControlInput1"><strong><?php echo e(__('titles.' . $col)); ?></strong></label>
                    <input type="text" name="<?php echo e($col); ?>" class="form-control" id="exampleFormControlInput1"
                        placeholder=" هنا" value="<?php echo e($global->$col); ?>">
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<hr>








<button type="submit" class="btn btn-primary"><?php echo e($button); ?></button>
<?php /**PATH C:\wamp64\www\koora\resources\views/admin/global/_form.blade.php ENDPATH**/ ?>