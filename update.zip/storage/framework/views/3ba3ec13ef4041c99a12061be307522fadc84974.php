
<?php /**PATH C:\wamp64\www\koora\resources\views/admin/local/_image.blade.php ENDPATH**/ ?>