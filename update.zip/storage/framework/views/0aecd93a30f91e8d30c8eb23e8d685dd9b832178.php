<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="description"
        content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <!-- Twitter meta-->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="@pratikborsadiya">
    <meta property="twitter:creator" content="@pratikborsadiya">
    <!-- Open Graph Meta-->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Vali Admin">
    <meta property="og:title" content="Vali - Free Bootstrap 4 admin theme">
    <meta property="og:url" content="http://pratikborsadiya.in/blog/vali-admin">
    <meta property="og:image" content="http://pratikborsadiya.in/blog/vali-admin/hero-social.png">
    <meta property="og:description"
        content="Vali is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>Koora Zoone</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">
    <!-- Font-icon css-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css"
        href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    



    <style>
    * {
        font-family: 'Tajawal', sans-serif;
    }
    </style>
</head>

<body class="app sidebar-mini">
    <!-- Navbar-->
    <header dir="ltr" class="app-header"><a class="app-header__logo" href="">Koora Zoone</a>
      
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar" dir="ltr"></div>
    <aside class="app-sidebar">
        <div class="app-sidebar__user" style="display: block; margin-left: auto; margin-right: auto; width: 70% ;">

            <!-- <div>
                <p class="app-sidebar__user-name"><?php echo e(Auth::user()->name ?? 'Not User'); ?></p>
                <p class="app-sidebar__user-designation"><?php echo e(Auth::user()->email ?? 'Not User'); ?></p>
            </div> -->
        </div>
        <ul class="app-menu">
            <li><a class="app-menu__item"  href="<?php echo e(route('dashboard.index')); ?>"><i
                        class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">لوحة
                        التحكم</span></a></li>
            <li><a class="app-menu__item <?php echo e(Request::is('*/glob-teams') ? "active" : ''); ?> " href="<?php echo e(route('glob-teams.index')); ?>"><i
                        class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">الفرق العالمية</span></a>
            </li>
            <li><a class="app-menu__item <?php echo e(Request::is('*/locl-teams') ? "active" : ''); ?>" href="<?php echo e(route('locl-teams.index')); ?>"><i
                class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">الفرق المحلية</span></a>
             </li>
           
            <li><a class="app-menu__item <?php echo e(Request::is('*/natio-teams') ? "active" : ''); ?>" href="<?php echo e(route('natio-teams.index')); ?>"><i
                        class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">المنتخبات</span></a>
            </li>
           
            <li><a class="app-menu__item <?php echo e(Request::is('*/posts') ? "active" : ''); ?>" href="<?php echo e(route('posts.index')); ?>"><i
                class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">الأخبار المنشورة</span></a>
             </li>

            <li><a class="app-menu__item <?php echo e(Request::is('*/suggests-team') ? "active" : ''); ?>" href="<?php echo e(route('suggests-team.index')); ?>"><i
                        class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">
                        الفرق المقترحة</span></a></li>
            <li><a class="app-menu__item <?php echo e(Request::is('*/reals') ? "active" : ''); ?>" href="<?php echo e(route('reals.index')); ?>"><i
                            class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">
                            الريلز </span></a></li>
            <li><a class="app-menu__item" href="<?php echo e(route('users.index')); ?>"><i
                        class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">المستخدمين</span></a>
            </li>

            <li><a id="logout" class="app-menu__item" ><i
                class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">تسجيل الخروج</span></a>
            </li>


            <form id="form" action=<?php echo e(route('admin.logout')); ?> method="POST">
                <?php echo csrf_field(); ?>
            </form>

            




        </ul>
    </aside>
    <main class="app-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <!-- Essential javascripts for application to work-->
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="<?php echo e(asset('js/plugins/pace.min.js')); ?>"></script>
    <!-- Page specific javascripts-->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/chart.js')); ?>"></script>

    <script src="https://code.jquery.com/jquery-3.6.1.min.js"  ></script>
   
    <?php echo $__env->yieldContent('scripts'); ?>

    <script>
        $('#logout').click(function() {
              $('#form').submit();
          });
  </script>
</body>

</html>
<?php /**PATH C:\wamp64\www\koora\resources\views/layouts/admin.blade.php ENDPATH**/ ?>